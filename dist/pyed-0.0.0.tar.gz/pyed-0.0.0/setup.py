from distutils.core import setup

setup(
    name='pyed',
    packages=['pyed',],
    license=open('LICENSE.txt').read(),
    long_description=open('Readme.md').read(),
)
